self.__SSG_MANIFEST=new Set(["\u002F404","\u002Fdonate","\u002Fnot-found","\u002F","\u002Fnym\u002Fmixnodecheck"]);self.__SSG_MANIFEST_CB&&self.__SSG_MANIFEST_CB()
/*!
* AerWebCopy Engine [version 6.3.0]
* Copyright Aeroson Systems & Co.
* File mirrored from https://nodes.guru/_next/static/pjU7uzHWXjXT5Wd3Mg96a/_ssgManifest.js
* At UTC time: 2022-04-18 15:58:23.206079
*/
